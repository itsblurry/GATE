package com.example.sanjuktalahiri.gate;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class SelectUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_user);

    }

    public void residentGo(View v)
    {
        Intent i1= new Intent(SelectUser.this, rLogin.class);
        startActivity(i1);
    }

    public void securityGo(View v)
    {
        Intent i2= new Intent(SelectUser.this, sLogin.class);
        startActivity(i2);
    }

}
