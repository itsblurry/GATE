package com.example.sanjuktalahiri.gate;

import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;


public class SelectUser extends AppCompatActivity {

    private ViewPager vp;
    private LinearLayout lin;

    private slider_adapter sa;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_user);

        vp= (ViewPager)findViewById(R.id.pager);
        lin=(LinearLayout)findViewById(R.id.linear);

        sa= new slider_adapter(this);

        vp.setAdapter(sa);

    }

    public void residentGo(View v)
    {
        Intent i1= new Intent(SelectUser.this, rLogin.class);
        startActivity(i1);
    }

    public void securityGo(View v)
    {
        Intent i2= new Intent(SelectUser.this, sLogin.class);
        startActivity(i2);
    }

}
