package com.example.sanjuktalahiri.gate;

import android.content.Context;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class slider_adapter extends PagerAdapter {

    Context context;
    LayoutInflater layIn;

    public slider_adapter(Context context) {
        this.context = context;

    }

    //Arrays
    public int[] slide_images = {
            R.drawable.qrcode,
            R.drawable.sos,
            R.drawable.notif
    };

    public String[] slide_heading = {
            "Scan your QR Code on the go",
            "SOS Button for emergency",
            "Allow Access to visitors from another location"
    };


    @Override
    public int getCount() {
        return slide_heading.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view == (RelativeLayout) o;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        layIn = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layIn.inflate(R.layout.slide_layout, container, false);

        ImageView slideImageView = (ImageView) view.findViewById(R.id.ivimage);
        TextView slideheading = (TextView) view.findViewById(R.id.tvheading);

        slideImageView.setImageResource(slide_images[position]);
        slideheading.setText(slide_heading[position]);

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {

        container.removeView((RelativeLayout) object);
    }
}

